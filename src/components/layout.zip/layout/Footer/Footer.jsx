// footer/Footer.jsx
import React from "react";
import { Link } from "react-router-dom";
import {
  FiFacebook,
  FiInstagram,
  FiYoutube,
  FiLinkedin,
  FiMail,
  FiPhone,
} from "react-icons/fi";
import { BsTwitterX } from "react-icons/bs";
import { GoLocation } from "react-icons/go";
// import FooterLogo from "../../../assets/FooterImages/C99_Logo.png";

import "./Footer.css";
//Logo
import Logo from '../../../../src/assets/Home_Page_Assets/c99x-logo.png'
export default function Footer() {
  const handleClickCourse = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="site-footer-f">
      <div className="footer-inner-f">
        {/* Logo + Tagline */}
        <div className="footer-left-f">
          <div className="logo-stack-f">
            <img src={Logo} alt="Code99 Logo" className="site-logo-f" />
            {/* <h3>C99X</h3> */}     
          </div>
          <p className="tagline-f">
            {/* Education should be free — we just maintain the space that makes it
            possible. */}
            Subscripe for new newsletter
            
          </p>
          <div className="Subscribe">
                <input type="text" placeholder="Your Email" className="subs-input" /> 
                <button className="subs-button">Subscribe</button>
            </div>
            <p>Your Information is never disclosed to third partise.</p>
            <div className="icon-list-subs">
                
                    <a href="https://www.facebook.com/code99itacademy/" target="_blank" rel="noreferrer"><FiFacebook /> </a>
                    <a href="https://www.instagram.com/code99_it_academy/" target="_blank" rel="noreferrer"><FiInstagram /> </a>
                    <a href="https://x.com/code99training" target="_blank" rel="noreferrer"><BsTwitterX /> </a>
                    <a href="https://www.youtube.com/@Code99ITAcademy" target="_blank" rel="noreferrer"><FiYoutube /> </a>
                    <a href="https://www.linkedin.com/company/code99itacademy/" target="_blank" rel="noreferrer"><FiLinkedin /> </a>
                
            </div>
        </div>

        {/* Courses + Nav Links (side by side) */}
        <div className="footer-course-nav-f">
          <div className="col-f col-courses-f">
            <h4 className="col-head">Services</h4>
            <ul>
              <li><Link to="" onClick={handleClickCourse}>Digital Marketing</Link></li>
              <li><Link to="" onClick={handleClickCourse}>Web Development</Link></li>
              <li><Link to="" onClick={handleClickCourse}>E-Commerce Website</Link></li>
              <li><Link to="" onClick={handleClickCourse}>Design & Viedo Editing</Link></li>
              <li><Link to="" onClick={handleClickCourse}>E-Commerce Site</Link></li>
              <li><Link to="" onClick={handleClickCourse}>Web Application</Link></li>
            </ul>
          </div>

          <div className="col-f col-navlink-f">
            <h4>Nav Link</h4>
            <ul>
              <li><Link to="/" onClick={handleClickCourse}>Home</Link></li>
              <li><Link to="/about" onClick={handleClickCourse}>About</Link></li>
              <li><Link to="/course/python-training-institute-in-chennai" onClick={handleClickCourse}>Services</Link></li>
              <li><Link to="/contact" onClick={handleClickCourse}>Contact</Link></li>
              <li><Link to="/Privacy" onClick={handleClickCourse}>Privacy Policy</Link></li>
            </ul>
          </div>
          {/* Contact */}
          <div className="col-f col-getin-f">
            <h4>Get In Touch</h4>
            <ul className="contact-list-f">
              <li> No 16, 1st floor, Sarathy Nagar,<br />Opp To Vijaya Nagar Bus Stop, Velachery,<br />Chennai - 600 042.</li>
              <li><a href="mailto:info@code99itacademy.com">info@code99itacademy.com</a></li>
              <li><a href="tel:6374510754">+91 63 745 10 754</a></li>
            </ul>
          </div>
          
        </div>

        {/* Social Media */}
        {/* <div className="col-f col-social-f">
          <h4>Social Media</h4>
          <ul className="icon-list-f">
            <li><a href="https://www.facebook.com/code99itacademy/" target="_blank" rel="noreferrer"><FiFacebook /> Facebook</a></li>
            <li><a href="https://www.instagram.com/code99_it_academy/" target="_blank" rel="noreferrer"><FiInstagram /> Instagram</a></li>
            <li><a href="https://x.com/code99training" target="_blank" rel="noreferrer"><BsTwitterX /> X</a></li>
            <li><a href="https://www.youtube.com/@Code99ITAcademy" target="_blank" rel="noreferrer"><FiYoutube /> YouTube</a></li>
            <li><a href="https://www.linkedin.com/company/code99itacademy/" target="_blank" rel="noreferrer"><FiLinkedin /> LinkedIn</a></li>
          </ul>
        </div> */}

        {/* Contact */}
        {/* <div className="col-f col-getin-f">
          <h4>Get In Touch</h4>
          <ul className="contact-list-f">
            <li> No 16, 1st floor, Sarathy Nagar,<br />Opp To Vijaya Nagar Bus Stop, Velachery,<br />Chennai - 600 042.</li>
            <li><a href="mailto:info@code99itacademy.com">info@code99itacademy.com</a></li>
            <li><a href="tel:6374510754">+91 63 745 10 754</a></li>
          </ul>
        </div> */}
      </div>

      <div className="footer-bottom-f">
        <div className="divider-footer-f" />
        <p>© 2025 C99X . All Rights Reserved.</p>
      </div>
    </footer>
  );
}