import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { FiMenu, FiX } from "react-icons/fi";
import Logo from '../../../../src/assets/Home_Page_Assets/c99x-logo.png'
import HoverLetters from "./HoverLetters";
import "./Navbar.css";
//Data
import ServicesData from '../../../pages/services/data/ServicesData'

export default function Navbar() {
  const [open, setOpen] = useState(false); // desktop dropdown
  const [mobileOpen, setMobileOpen] = useState(false); // mobile nav panel
  const [mobileDropdown, setMobileDropdown] = useState(false); // mobile dropdown
  const dropdownRef = useRef(null);

  // Desktop dropdown close on outside click
  useEffect(() => {
    const handleOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutside);
    return () => document.removeEventListener("mousedown", handleOutside);
  }, []);

  // Smooth scroll for Servicess
  function handleClickServices() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // Mobile: close navbar when any link clicks
  const handleMobileLinkClick = () => {
    setMobileOpen(false);
    setMobileDropdown(false);
    setOpen(false);
    handleClickServices();
  };

  // Mobile: toggle dropdown only (Servicess)
  const handleMobileDropdownToggle = () => {
    setMobileDropdown((p) => !p);
  };

  return (
    <header className="header-nav">
      <div className="container-nav">
        {/* Logo */}
        <div className="logo-section">
          <Link to="/">
            <img src={Logo} alt="Logo" className="logo" />
          </Link>
          {/* <span className="brand-name">C99X</span> */}
        </div>

        {/* Desktop Navigation */}
        <nav className="nav hide-on-mobile">
          <Link style={{fontSize:'15px', marginTop:'6px'}} to="/home" onClick={handleMobileLinkClick} ><HoverLetters text="Home" /></Link>
          <div className="dropdown" ref={dropdownRef}>
            <div style={{fontSize:'15px'}} className="dropbtn" onClick={() => setOpen((p) => !p)}>
              {/* SERVICES  */}
              <HoverLetters text= "Services"/> {open ? "▴" : "▾"}
            </div>

            <div className={`dropdown-content ${open ? "show" : ""}`}>
              {ServicesData.map((service) => (
                <Link
                  key={service.id}
                  to={`/services/${service.id}`}
                  onClick={() => { setOpen(false); handleClickServices(); }}
                >
                  {service.title}
                </Link>
              ))}
            </div>

          </div>
          <Link style={{fontSize:'15px', marginTop:'6px'}} to="/about" onClick={handleMobileLinkClick}><HoverLetters text="About us" /></Link>
          {/* <Link style={{fontSize:'15px', marginTop:'6px'}} to="/blog" onClick={handleMobileLinkClick}>BLOG</Link> */}
          <Link style={{fontSize:'15px', marginTop:'6px'}} to="/contact" onClick={handleMobileLinkClick}><HoverLetters text="Contact" />  </Link>
        </nav>

        {/* Desktop Phone Button */}
        {/* <div className="phone-section hide-on-mobile">
          <a href="tel:+916374510754" className="call-button"
           onClick={() => {
        window.open(
          "https://wa.me/6374510754?text=I'm interested, I want to join the Services.",
          "_blank"
        );
        }}
           >
            <span> Enroll now</span>
          </a>
        </div> */}

        {/* Hamburger icon (shown only below 900px) */}
        <button
          className="hamburger show-on-mobile"
          style={{ backgroundColor: 'white', color: 'black' }}
          aria-label="Open menu"
          onClick={() => setMobileOpen((prev) => !prev)}
        >
          {mobileOpen ? <FiX size={28} /> : <FiMenu size={28} />}
        </button>
      </div>

      {/* Mobile Nav Panel */}
      <div className={`mobile-nav-panel ${mobileOpen ? "show" : ""}`}>
        <nav>
          <Link to="/" onClick={handleMobileLinkClick}>HOME</Link>
          <div className="dropdown-mobile">
            <div className="dropbtn-mobile" onClick={handleMobileDropdownToggle}>
              SERVICES {mobileDropdown ? "▴" : "▾"}
            </div>
            <div className={`dropdown-content-mobile ${mobileDropdown ? "show" : ""}`}>
              {ServicesData.map((Services) => (
                <Link
                  key={Services.id}
                  to={`/Services/${Services.slug ?? Services.id}`}
                  onClick={handleMobileLinkClick}
                >
                  {Services.title}
                </Link>
              ))}
            </div>
          </div>
          <Link to="/about" onClick={handleMobileLinkClick}>ABOUT US</Link>
          {/* <Link to="/blog" onClick={handleMobileLinkClick}>BLOG</Link> */}
          <Link to="/contact" onClick={handleMobileLinkClick}>CONTACT</Link>
        </nav>
      </div>
    </header>
  );
}